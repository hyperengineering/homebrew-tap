# Swarm

Swarm provisions virtual machines and deploys [devcontainers](https://containers.dev/) on them. It manages the full lifecycle: VM creation, bootstrapping (Docker, Node.js, devcontainer CLI, swarm-agent), container deployment, and teardown.

## Architecture

Swarm uses a client/server architecture with three components:

- **`swarm`** — CLI client. Sends HTTP requests to the server and handles interactive operations (shell, port forwarding) directly via SSH.
- **`swarm-server`** — Control-plane daemon. Manages the registry, talks to cloud providers, bootstraps VMs, and communicates with agents over SSH.
- **`swarm-agent`** — Runs on each VM. Manages Docker containers via the devcontainer CLI and reports status back to the server.

```
CLI (swarm) ──HTTP──▶ Server (swarm-server) ──SSH──▶ Agent (swarm-agent)
                                                          │
                                                     Docker containers
```

The CLI only needs the server URL to operate. All cloud credentials, SSH keys, and agent binaries are configured on the server.

## Getting started

### Prerequisites

- Go 1.25+

### Build

```sh
make build-all
```

This produces three binaries in `dist/`:

| Binary | Purpose |
|--------|---------|
| `swarm` | CLI client |
| `swarm-server` | Control-plane server |
| `swarm-agent-linux-amd64` | Agent binary (deployed to VMs) |

To build individually:

```sh
make build          # CLI only
make build-server   # Server only
make build-agent    # Agent only (linux/amd64)
```

Install the CLI to your `$GOPATH/bin`:

```sh
make install
```

### Configure the CLI

Point the CLI at a running server:

```sh
swarm config set server https://your-server:8800
```

`:8800` is the server's default `listen_addr`. If you've overridden it
in `swarm-server.json`, use that port instead.

The server's API is protected by mutual TLS. After the server's first
start (which prints a one-time enrollment token), enroll this machine:

```sh
swarm login --token <token>
```

### Configure the server

Create a `swarm-server.json` configuration file:

```json
{
  "listen_addr": ":8800",
  "registry_path": "/var/lib/swarm/registry.json",
  "ssh_key_path": "/etc/swarm/id_ed25519",
  "provider_token_cmd": "op read op://Vault/UpCloud/token",
  "agent_binary_path": "/usr/bin/swarm-agent",
  "log_level": "info"
}
```

Credential fields (`provider_token_cmd`, `provider_username_cmd`, `provider_password_cmd`) are shell commands executed at startup, so you can use any secret manager (1Password, Bitwarden, `pass`, etc.) or fall back to environment variables.

Start the server:

```sh
swarm-server -config swarm-server.json
```

See [`packaging/`](packaging/) for systemd unit files and Docker Compose configuration.

## Usage

### VM management

```sh
swarm vm create --template ubuntu-24.04 --plan 2xCPU-4GB
swarm vm list
swarm vm info <vm-id>
swarm vm bootstrap <vm-id>
swarm vm destroy <vm-id>
```

### Container management

```sh
swarm container deploy --vm <vm-id> --repo https://github.com/org/repo
swarm container list
swarm container info <container-id>
swarm container rename <container-id> <alias>
swarm container rm <container-id>
```

> Shell and port-forward into a container are not available from the CLI
> in this release. Use `ssh root@<vm-ip> "docker exec -it <docker-id> bash"`
> directly, where `<docker-id>` is the `CONTAINER ID` from
> `swarm container list`.

### Container HTTP proxy

Services running inside a deployed container (bound to `0.0.0.0:8900`
by default) are reachable from any client authenticated to swarm-server
via `ANY /api/containers/<id>/proxy/<path>`. Authentication is mutual
TLS — see the security note in
[`docs/container-proxy.md`](docs/container-proxy.md) and the
[`examples/proxy-echo/`](examples/proxy-echo/) reference container.

### Interactive TUI

Launch a terminal dashboard for managing VMs and containers:

```sh
swarm tui
```

## Development

```sh
make test           # Run tests
make test-race      # Race condition detection
make test-cover     # Generate coverage report
make lint           # golangci-lint
make fmt            # Format code
make vet            # Go vet analysis
make ci             # Full pipeline: fmt, vet, lint, test, build
```

## Project structure

```
cmd/
  swarm/            CLI client
  swarm-server/     Control-plane server
  swarm-agent/      VM agent
internal/
  agent/            Agent types, client, devcontainer config parsing
  api/              API request/response types and client
  bootstrap/        VM bootstrapping (Docker, Node.js, devcontainer CLI)
  cloud/            Cloud provider interface and UpCloud implementation
  config/           Configuration loading and credential resolution
  registry/         File-based VM and container registry
  server/           Control-plane HTTP server
  sshclient/        SSH client for remote execution
  tui/              Terminal UI (Bubble Tea + Lip Gloss)
packaging/          systemd units, Docker Compose, install scripts
docs/               User guide and design documents
```

## Documentation

- [User's Guide](docs/guide.md) — full setup, configuration, and command reference
- [Container HTTP Proxy](docs/container-proxy.md) — reach services running inside deployed containers
- [Container HTTP Proxy — Client Integration](docs/container-proxy-client.md) — wire contract for teams building HTTP clients against the proxy
- [TUI Implementation](docs/tui-implementation.md) — terminal UI architecture

## License

[MIT](LICENSE.md)
